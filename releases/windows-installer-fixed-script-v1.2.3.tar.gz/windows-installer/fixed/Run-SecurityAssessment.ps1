<#
.SYNOPSIS
    Runs a comprehensive security assessment using SecurePulse and optionally SCuBA
.DESCRIPTION
    This script runs security assessments on Microsoft 365 tenant using SecurePulse modules
    and optionally SCuBA baseline checks. Results are combined into a single comprehensive report.
.PARAMETER TenantId
    The Microsoft 365 tenant ID to assess
.PARAMETER ClientId
    The application (client) ID for Microsoft Graph API access
.PARAMETER ClientSecret
    The client secret for Microsoft Graph API access
.PARAMETER UseScuba
    If specified, also runs SCuBA assessment
.PARAMETER OutputPath
    The path where reports should be saved. Defaults to "./reports"
.PARAMETER ModulesToRun
    Comma-separated list of modules to run. Options: DriftGuard,AccessWatch,LicenseLogic
    Default: all modules
.EXAMPLE
    .\Run-SecurityAssessment.ps1 -TenantId "1a2b3c4d-1234-5678-9012-abc123def456" -ClientId "app-id" -ClientSecret "app-secret"
.EXAMPLE
    .\Run-SecurityAssessment.ps1 -TenantId "1a2b3c4d-1234-5678-9012-abc123def456" -ClientId "app-id" -ClientSecret "app-secret" -UseScuba
.NOTES
    Author: Open Door MSP
    Version: 1.2.3
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [string]$TenantId,
    
    [Parameter(Mandatory=$true)]
    [string]$ClientId,
    
    [Parameter(Mandatory=$true)]
    [string]$ClientSecret,
    
    [Parameter(Mandatory=$false)]
    [switch]$UseScuba,
    
    [Parameter(Mandatory=$false)]
    [string]$OutputPath = ".\reports",
    
    [Parameter(Mandatory=$false)]
    [string]$ModulesToRun = "DriftGuard,AccessWatch,LicenseLogic"
)

$ErrorActionPreference = "Stop"
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# Ensure output directory exists
if (-not (Test-Path -Path $OutputPath)) {
    New-Item -Path $OutputPath -ItemType Directory -Force | Out-Null
}

# Set environment variables for SecurePulse
$env:MS_CLIENT_ID = $ClientId
$env:MS_CLIENT_SECRET = $ClientSecret
$env:MS_TENANT_ID = $TenantId

try {
    # Step 1: Run SCuBA assessment first if requested
    if ($UseScuba) {
        Write-Host "Step 1: Running SCuBA assessment..." -ForegroundColor Cyan
        Push-Location $scriptDir
        
        # Check if ScubaGear is installed
        if (-not (Get-Module -ListAvailable -Name ScubaGear)) {
            Write-Host "SCuBA not installed. Please run the installer with -InstallScuba" -ForegroundColor Red
            return
        }
        
        # Create SCuBA output directory
        $scubaOutputPath = Join-Path $OutputPath "scuba"
        if (-not (Test-Path -Path $scubaOutputPath)) {
            New-Item -Path $scubaOutputPath -ItemType Directory -Force | Out-Null
        }
        
        # Run SCuBA assessment
        try {
            Write-Host "Importing ScubaGear module..." -ForegroundColor Cyan
            Import-Module ScubaGear
            
            Write-Host "Running Invoke-SCuBA with all products..." -ForegroundColor Cyan
            Invoke-SCuBA -ProductNames * -OutputPath $scubaOutputPath
            Write-Host "SCuBA assessment completed successfully" -ForegroundColor Green
            
            # Import SCuBA results into SecurePulse format
            Write-Host "Importing SCuBA results into SecurePulse format..." -ForegroundColor Cyan
            
            if (Test-Path -Path ".\venv\Scripts\python.exe") {
                & .\venv\Scripts\python.exe import_scuba_results.py --scuba-path $scubaOutputPath
            } else {
                python import_scuba_results.py --scuba-path $scubaOutputPath
            }
            
            Write-Host "SCuBA results have been imported and are ready for reporting" -ForegroundColor Green
        }
        catch {
            Write-Host "Error running SCuBA assessment: $_" -ForegroundColor Red
            Write-Host "You may need to run 'Initialize-SCuBA' manually first" -ForegroundColor Yellow
            Write-Host "Continuing with SecurePulse modules..." -ForegroundColor Yellow
        }
    }
    
    # Step 2: Run SecurePulse assessment
    Write-Host "Step 2: Running SecurePulse modules..." -ForegroundColor Cyan
    Push-Location $scriptDir
    
    # Activate virtual environment and run SecurePulse
    $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
    
    # Run the verified modules with error handling
    try {
        if (Test-Path -Path ".\venv\Scripts\python.exe") {
            # Use virtual environment if it exists
            & .\venv\Scripts\python.exe run_verified_modules.py --modules $ModulesToRun
        } else {
            # Otherwise use system Python
            python run_verified_modules.py --modules $ModulesToRun
        }
    }
    catch {
        Write-Host "Error running SecurePulse modules: $_" -ForegroundColor Red
        Write-Host "This might be due to missing dependencies or configuration issues." -ForegroundColor Yellow
        Write-Host "The report will still be generated with available data." -ForegroundColor Yellow
    }
    
    # Find the most recent results file
    $recentResultsFile = Get-ChildItem -Path ".\verified_scan\verified_scan_results_*.json" | 
                        Sort-Object LastWriteTime -Descending | 
                        Select-Object -First 1
    
    if ($recentResultsFile) {
        Write-Host "SecurePulse assessment completed successfully" -ForegroundColor Green
        Write-Host "Results saved to: $recentResultsFile" -ForegroundColor Green
    } else {
        Write-Host "Warning: Could not find SecurePulse results file" -ForegroundColor Yellow
    }
    
    # Step 3: Generate HTML report
    Write-Host "Generating HTML report..." -ForegroundColor Cyan
    
    # Find the most recent reports
    $recentDriftReport = Get-ChildItem -Path ".\verified_scan\drift\drift_report_*.json" | 
                    Sort-Object LastWriteTime -Descending | 
                    Select-Object -First 1
                    
    $recentAccessReport = Get-ChildItem -Path ".\verified_scan\access_report_*.json" | 
                        Sort-Object LastWriteTime -Descending | 
                        Select-Object -First 1
                        
    $recentLicenseReport = Get-ChildItem -Path ".\verified_scan\license_report_*.json" | 
                        Sort-Object LastWriteTime -Descending | 
                        Select-Object -First 1
    
    # Create a simple HTML report
    $reportTimestamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $reportFile = Join-Path $OutputPath "comprehensive_report_$reportTimestamp.html"
    
    # Generate report content
    $reportContent = @"
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>SecurePulse Comprehensive Report</title>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 1200px; margin: 0 auto; padding: 20px; }
        h1, h2, h3 { color: #2c3e50; }
        .header { border-bottom: 2px solid #2c3e50; padding-bottom: 10px; margin-bottom: 20px; }
        .section { margin-bottom: 30px; border: 1px solid #ddd; padding: 15px; border-radius: 5px; }
        .tenant-info { background-color: #f8f9fa; padding: 15px; border-radius: 5px; margin-bottom: 20px; }
        .compliance-good { color: #27ae60; }
        .compliance-warning { color: #f39c12; }
        .compliance-bad { color: #e74c3c; }
        .summary-box { display: inline-block; padding: 10px; margin: 5px; background-color: #f5f5f5; border-radius: 5px; min-width: 150px; text-align: center; }
        .module-title { background-color: #2c3e50; color: white; padding: 5px 10px; border-radius: 3px; }
    </style>
</head>
<body>
    <div class="header">
        <h1>SecurePulse Comprehensive Security Report</h1>
        <p>Generated on $(Get-Date -Format "MMMM d, yyyy 'at' h:mm tt")</p>
    </div>
    
    <div class="tenant-info">
        <h2>Tenant Information</h2>
        <p>Tenant ID: $TenantId</p>
    </div>
    
    <div class="section">
        <h2><span class="module-title">Summary</span></h2>
        <p>This report combines results from multiple security assessment modules:</p>
        <ul>
"@

    if ($recentDriftReport) { $reportContent += "            <li>DriftGuard - Configuration Drift Detection</li>`n" }
    if ($recentAccessReport) { $reportContent += "            <li>AccessWatch - Identity and Access Security</li>`n" }
    if ($recentLicenseReport) { $reportContent += "            <li>LicenseLogic - License Usage Optimization</li>`n" }
    if ($UseScuba) { $reportContent += "            <li>SCuBA - CISA Secure Cloud Business Applications</li>`n" }

    $reportContent += @"
        </ul>
    </div>
"@

    # Add drift detection results if available
    if ($recentDriftReport) {
        Write-Host "Adding DriftGuard results to report..." -ForegroundColor Cyan
        
        # Read drift report
        $driftData = Get-Content -Path $recentDriftReport.FullName -Raw | ConvertFrom-Json
        
        # Calculate compliance score
        $complianceScore = $driftData.summary.overallComplianceScore
        $complianceClass = "compliance-bad"
        if ($complianceScore -ge 90) { $complianceClass = "compliance-good" }
        elseif ($complianceScore -ge 70) { $complianceClass = "compliance-warning" }
        
        $reportContent += @"
    <div class="section">
        <h2><span class="module-title">DriftGuard</span> Configuration Drift Detection</h2>
        
        <div class="summary-box">
            <h3>Overall Compliance</h3>
            <p class="$complianceClass">$($complianceScore.ToString("0.0"))%</p>
        </div>
        
        <div class="summary-box">
            <h3>Requirements</h3>
            <p>Total: $($driftData.summary.totalRequirements)</p>
            <p>Compliant: $($driftData.summary.compliantRequirements)</p>
            <p>Non-Compliant: $($driftData.summary.nonCompliantRequirements)</p>
        </div>
        
        <h3>Workload Compliance</h3>
        <ul>
"@

        # Add workload compliance
        foreach ($workload in $driftData.workloads.PSObject.Properties) {
            $wName = $workload.Name
            $wScore = $workload.Value.complianceScore
            
            $wClass = "compliance-bad"
            if ($wScore -ge 90) { $wClass = "compliance-good" }
            elseif ($wScore -ge 70) { $wClass = "compliance-warning" }
            
            $reportContent += "            <li>${wName}: <span class=`"${wClass}`">${wScore}%</span></li>`n"
        }

        $reportContent += @"
        </ul>
        
        <h3>Top Issues</h3>
        <ul>
"@

        # Add top 5 non-compliant issues
        $topIssues = $driftData.driftDetails | Where-Object { $_.status -eq "Non-Compliant" } | Select-Object -First 5
        
        foreach ($issue in $topIssues) {
            $reportContent += "            <li><strong>$($issue.title)</strong> - $($issue.description)</li>`n"
        }

        $reportContent += @"
        </ul>
    </div>
"@
    }

    # Add AccessWatch results if available
    if ($recentAccessReport) {
        Write-Host "Adding AccessWatch results to report..." -ForegroundColor Cyan
        
        # Read access report
        $accessData = Get-Content -Path $recentAccessReport.FullName -Raw | ConvertFrom-Json
        
        # Calculate MFA score
        $mfaScore = $accessData.mfaCompliance.mfaAdoptionRate
        $mfaClass = "compliance-bad"
        if ($mfaScore -ge 90) { $mfaClass = "compliance-good" }
        elseif ($mfaScore -ge 70) { $mfaClass = "compliance-warning" }
        
        $reportContent += @"
    <div class="section">
        <h2><span class="module-title">AccessWatch</span> Identity and Access Security</h2>
        
        <div class="summary-box">
            <h3>MFA Adoption</h3>
            <p class="$mfaClass">$($mfaScore.ToString("0.0"))%</p>
        </div>
        
        <div class="summary-box">
            <h3>Admin MFA</h3>
            <p>$($accessData.mfaCompliance.adminMfaAdoptionRate.ToString("0.0"))%</p>
        </div>
        
        <div class="summary-box">
            <h3>At-Risk Users</h3>
            <p>$($accessData.mfaCompliance.atRiskUsers.Count)</p>
        </div>
        
        <h3>Conditional Access Policies</h3>
        <p>MFA Policy Coverage: $($accessData.conditionalAccessAnalysis.mfaPolicyCoverage)</p>
    </div>
"@
    }

    # Add LicenseLogic results if available
    if ($recentLicenseReport) {
        Write-Host "Adding LicenseLogic results to report..." -ForegroundColor Cyan
        
        # Read license report
        $licenseData = Get-Content -Path $recentLicenseReport.FullName -Raw | ConvertFrom-Json
        
        $reportContent += @"
    <div class="section">
        <h2><span class="module-title">LicenseLogic</span> License Usage Optimization</h2>
        
        <div class="summary-box">
            <h3>Total Users</h3>
            <p>$($licenseData.metadata.totalUsers)</p>
        </div>
        
        <div class="summary-box">
            <h3>License SKUs</h3>
            <p>$($licenseData.metadata.totalSkus)</p>
        </div>
        
        <div class="summary-box">
            <h3>Optimization</h3>
            <p>Users without License: $($licenseData.metadata.usersWithNoLicense)</p>
            <p>Disabled with License: $($licenseData.metadata.disabledWithLicense)</p>
        </div>
    </div>
"@
    }
    
    # Add SCuBA results if available
    if ($UseScuba) {
        Write-Host "Adding SCuBA results to report..." -ForegroundColor Cyan
        
        # Find SCuBA-imported drift report
        $scubaDriftReport = Get-ChildItem -Path ".\verified_scan\drift\drift_report_scuba_*.json" | 
                        Sort-Object LastWriteTime -Descending | 
                        Select-Object -First 1
                        
        if ($scubaDriftReport) {
            # Read SCuBA drift report
            $scubaData = Get-Content -Path $scubaDriftReport.FullName -Raw | ConvertFrom-Json
            
            # Calculate compliance score
            $scubaScore = $scubaData.summary.overallComplianceScore
            $scubaClass = "compliance-bad"
            if ($scubaScore -ge 90) { $scubaClass = "compliance-good" }
            elseif ($scubaScore -ge 70) { $scubaClass = "compliance-warning" }
            
            $reportContent += @"
    <div class="section">
        <h2><span class="module-title">SCuBA</span> CISA Secure Cloud Business Applications</h2>
        
        <div class="summary-box">
            <h3>Overall Compliance</h3>
            <p class="$scubaClass">$($scubaScore.ToString("0.0"))%</p>
        </div>
        
        <div class="summary-box">
            <h3>Requirements</h3>
            <p>Total: $($scubaData.summary.totalRequirements)</p>
            <p>Compliant: $($scubaData.summary.compliantRequirements)</p>
            <p>Non-Compliant: $($scubaData.summary.nonCompliantRequirements)</p>
        </div>
        
        <h3>Workload Compliance</h3>
        <ul>
"@

            # Add workload compliance
            foreach ($workload in $scubaData.workloads.PSObject.Properties) {
                $wName = $workload.Name
                $wScore = $workload.Value.complianceScore
                
                $wClass = "compliance-bad"
                if ($wScore -ge 90) { $wClass = "compliance-good" }
                elseif ($wScore -ge 70) { $wClass = "compliance-warning" }
                
                $reportContent += "            <li>${wName}: <span class=`"${wClass}`">${wScore}%</span></li>`n"
            }

            $reportContent += @"
        </ul>
    </div>
"@
        } else {
            $reportContent += @"
    <div class="section">
        <h2><span class="module-title">SCuBA</span> CISA Secure Cloud Business Applications</h2>
        <p>SCuBA assessment was run, but the results could not be imported. Please check the SCuBA output directory.</p>
    </div>
"@
        }
    }

    # Close HTML report
    $reportContent += @"
    <footer>
        <p>Generated by SecurePulse - © $(Get-Date -Format "yyyy")</p>
    </footer>
</body>
</html>
"@
    
    # Save the report
    Set-Content -Path $reportFile -Value $reportContent
    
    Write-Host "Assessment complete!" -ForegroundColor Green
    Write-Host "HTML Report is available at: $reportFile" -ForegroundColor Green
    
    # Try to open the report in the default browser
    try {
        Start-Process $reportFile
    }
    catch {
        Write-Host "Report generated but could not be opened automatically. Please open it manually." -ForegroundColor Yellow
    }
    
    Pop-Location
}
catch {
    Write-Host "Error during assessment: $_" -ForegroundColor Red
}
finally {
    # Clear environment variables
    Remove-Item Env:\MS_CLIENT_ID -ErrorAction SilentlyContinue
    Remove-Item Env:\MS_CLIENT_SECRET -ErrorAction SilentlyContinue
    Remove-Item Env:\MS_TENANT_ID -ErrorAction SilentlyContinue
}