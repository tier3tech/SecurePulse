<#
.SYNOPSIS
    Installs SecurePulse and its dependencies on Windows.
.DESCRIPTION
    This script installs SecurePulse, SCuBA, and all required dependencies on Windows.
    It sets up Python, required modules, PowerShell modules, and configures everything
    for easy execution.
.PARAMETER InstallPath
    The path where SecurePulse should be installed. Defaults to "%USERPROFILE%\SecurePulse".
.PARAMETER InstallScuba
    If specified, also installs SCuBA (Secure Cloud Business Applications) assessment tool.
.PARAMETER SkipPython
    If specified, skips Python installation (assumes Python 3.8+ is already installed).
.PARAMETER Branch
    The GitHub branch to clone. Defaults to "main".
.EXAMPLE
    .\Install-SecurePulse-Full.ps1
.EXAMPLE
    .\Install-SecurePulse-Full.ps1 -InstallScuba -InstallPath "C:\SecurePulse"
.NOTES
    Author: Open Door MSP
    Version: 1.2.0
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory=$false)]
    [string]$InstallPath = "$env:USERPROFILE\SecurePulse",
    
    [Parameter(Mandatory=$false)]
    [switch]$InstallScuba,
    
    [Parameter(Mandatory=$false)]
    [switch]$SkipPython,
    
    [Parameter(Mandatory=$false)]
    [string]$Branch = "main"
)

#Requires -RunAsAdministrator

# Function to check if a program is installed
function Test-ProgramInstalled {
    param(
        [Parameter(Mandatory=$true)]
        [string]$ProgramName
    )
    
    try {
        Get-Command $ProgramName -ErrorAction Stop | Out-Null
        return $true
    }
    catch {
        return $false
    }
}

# Function to check Python version
function Test-PythonVersion {
    try {
        $pythonVersion = (python --version) 2>&1
        if ($pythonVersion -match '(\d+)\.(\d+)\.(\d+)') {
            $major = [int]$Matches[1]
            $minor = [int]$Matches[2]
            if ($major -ge 3 -and $minor -ge 8) {
                return $true
            }
        }
        return $false
    }
    catch {
        return $false
    }
}

# Function to install Microsoft Visual C++ Redistributable
function Install-VCRedist {
    Write-Host "Installing Microsoft Visual C++ Redistributable..." -ForegroundColor Cyan
    $vcRedistUrl = "https://aka.ms/vs/17/release/vc_redist.x64.exe"
    $vcRedistInstaller = "$env:TEMP\vc_redist_securepulse.exe"
    
    try {
        # Remove existing installer if it exists
        if (Test-Path $vcRedistInstaller) {
            try {
                Remove-Item $vcRedistInstaller -Force -ErrorAction Stop
            }
            catch {
                Write-Host "Warning: Could not remove existing VC++ Redistributable installer. Will try to continue anyway." -ForegroundColor Yellow
            }
        }
        
        # Download and install
        Invoke-WebRequest -Uri $vcRedistUrl -OutFile $vcRedistInstaller -UseBasicParsing
        Start-Process -FilePath $vcRedistInstaller -ArgumentList "/quiet", "/norestart" -Wait
        
        # Clean up
        try {
            Remove-Item $vcRedistInstaller -Force -ErrorAction SilentlyContinue
        }
        catch {
            Write-Host "Warning: Could not remove VC++ Redistributable installer. You can delete it manually: $vcRedistInstaller" -ForegroundColor Yellow
        }
        
        Write-Host "Microsoft Visual C++ Redistributable installed successfully." -ForegroundColor Green
    }
    catch {
        Write-Host "Failed to install Microsoft Visual C++ Redistributable: $_" -ForegroundColor Red
        Write-Host "You may need to install it manually from: $vcRedistUrl" -ForegroundColor Yellow
    }
}

# Function to download file from GitHub
function Download-GitHubFile {
    param(
        [Parameter(Mandatory=$true)]
        [string]$RepoPath,
        
        [Parameter(Mandatory=$true)]
        [string]$DestinationPath,
        
        [Parameter(Mandatory=$false)]
        [string]$Branch = "main"
    )
    
    $url = "https://raw.githubusercontent.com/tier3tech/SecurePulse/$Branch/$RepoPath"
    
    try {
        # Create directory if it doesn't exist
        $destDir = [System.IO.Path]::GetDirectoryName($DestinationPath)
        if (-not (Test-Path -Path $destDir)) {
            New-Item -Path $destDir -ItemType Directory -Force | Out-Null
        }
        
        Invoke-WebRequest -Uri $url -OutFile $DestinationPath -UseBasicParsing
        return $true
    }
    catch {
        Write-Host "Failed to download file: $url" -ForegroundColor Red
        Write-Host "Error: $_" -ForegroundColor Red
        return $false
    }
}

# Create log directory
$logDir = "$InstallPath\logs"
if (-not (Test-Path -Path $logDir)) {
    New-Item -Path $logDir -ItemType Directory -Force | Out-Null
}

# Setup logging
$logFile = "$logDir\install_$(Get-Date -Format 'yyyyMMdd_HHmmss').log"
Start-Transcript -Path $logFile

Write-Host "===================================================" -ForegroundColor Cyan
Write-Host "SecurePulse Full Installer" -ForegroundColor Cyan
Write-Host "===================================================" -ForegroundColor Cyan
Write-Host "Installation Path: $InstallPath" -ForegroundColor Cyan
Write-Host "Install SCuBA: $InstallScuba" -ForegroundColor Cyan
Write-Host "Skip Python: $SkipPython" -ForegroundColor Cyan
Write-Host "GitHub Branch: $Branch" -ForegroundColor Cyan
Write-Host "Log File: $logFile" -ForegroundColor Cyan
Write-Host "===================================================" -ForegroundColor Cyan

try {
    # Create installation directory
    if (-not (Test-Path -Path $InstallPath)) {
        Write-Host "Creating installation directory: $InstallPath" -ForegroundColor Cyan
        New-Item -Path $InstallPath -ItemType Directory -Force | Out-Null
    }
    
    # Step 1: Install prerequisites
    Write-Host "Step 1: Installing prerequisites..." -ForegroundColor Cyan
    
    # Install Microsoft Visual C++ Redistributable
    Install-VCRedist
    
    # Install Python if not present or version < 3.8
    if ((-not (Test-ProgramInstalled "python")) -or (-not (Test-PythonVersion)) -and (-not $SkipPython)) {
        Write-Host "Python 3.8+ not found. Installing Python 3.10..." -ForegroundColor Cyan
        $pythonUrl = "https://www.python.org/ftp/python/3.10.11/python-3.10.11-amd64.exe"
        $pythonInstaller = "$env:TEMP\python-installer.exe"
        Invoke-WebRequest -Uri $pythonUrl -OutFile $pythonInstaller -UseBasicParsing
        Start-Process -FilePath $pythonInstaller -ArgumentList "/quiet", "InstallAllUsers=1", "PrependPath=1", "Include_test=0" -Wait
        Remove-Item $pythonInstaller -Force
        
        # Refresh PATH
        $env:Path = [System.Environment]::GetEnvironmentVariable("Path", "Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path", "User")
    }
    
    # Step 2: Setup SecurePulse file structure
    Write-Host "Step 2: Setting up SecurePulse directory structure..." -ForegroundColor Cyan
    Push-Location $InstallPath
    
    # Create necessary directories
    $sourceDirs = @(
        "AccessWatch",
        "DriftGuardEngine",
        "DriftGuardEngine/baselines",
        "reporting_engine",
        "reporting_engine/templates",
        "baselines",
        "verified_scan",
        "verified_scan/drift",
        "reports"
    )
    
    foreach ($dir in $sourceDirs) {
        $dirPath = "$InstallPath\$($dir.Replace('/', '\'))"
        if (-not (Test-Path -Path $dirPath)) {
            Write-Host "Creating directory: $dirPath" -ForegroundColor Cyan
            New-Item -Path $dirPath -ItemType Directory -Force | Out-Null
        }
    }
    
    # Step 3: Download core files from GitHub
    Write-Host "Step 3: Downloading SecurePulse files..." -ForegroundColor Cyan
    
    # Define core files to download
    $coreFiles = @(
        @{Path="__init__.py"; Destination="$InstallPath\__init__.py"},
        
        # AccessWatch module
        @{Path="AccessWatch/__init__.py"; Destination="$InstallPath\AccessWatch\__init__.py"},
        @{Path="AccessWatch/access_analyzer.py"; Destination="$InstallPath\AccessWatch\access_analyzer.py"},
        @{Path="AccessWatch/policy_monitor.py"; Destination="$InstallPath\AccessWatch\policy_monitor.py"},
        
        # DriftGuardEngine module
        @{Path="DriftGuardEngine/__init__.py"; Destination="$InstallPath\DriftGuardEngine\__init__.py"},
        @{Path="DriftGuardEngine/baseline_manager.py"; Destination="$InstallPath\DriftGuardEngine\baseline_manager.py"},
        @{Path="DriftGuardEngine/drift_detector.py"; Destination="$InstallPath\DriftGuardEngine\drift_detector.py"},
        @{Path="DriftGuardEngine/m365_config.py"; Destination="$InstallPath\DriftGuardEngine\m365_config.py"},
        
        # DriftGuardEngine baselines
        @{Path="DriftGuardEngine/baselines/aad.json"; Destination="$InstallPath\DriftGuardEngine\baselines\aad.json"},
        @{Path="DriftGuardEngine/baselines/defender.json"; Destination="$InstallPath\DriftGuardEngine\baselines\defender.json"},
        @{Path="DriftGuardEngine/baselines/exo.json"; Destination="$InstallPath\DriftGuardEngine\baselines\exo.json"},
        @{Path="DriftGuardEngine/baselines/sharepoint.json"; Destination="$InstallPath\DriftGuardEngine\baselines\sharepoint.json"},
        @{Path="DriftGuardEngine/baselines/teams.json"; Destination="$InstallPath\DriftGuardEngine\baselines\teams.json"},
        
        # LicenseLogic module
        @{Path="LicenseLogic.py"; Destination="$InstallPath\LicenseLogic.py"},
        
        # Reporting engine
        @{Path="reporting_engine/__init__.py"; Destination="$InstallPath\reporting_engine\__init__.py"},
        @{Path="reporting_engine/report_generator.py"; Destination="$InstallPath\reporting_engine\report_generator.py"},
        
        # Core files
        @{Path="run_verified_modules.py"; Destination="$InstallPath\run_verified_modules.py"},
        @{Path="requirements.txt"; Destination="$InstallPath\requirements.txt"},
        @{Path="import_scuba_results.py"; Destination="$InstallPath\import_scuba_results.py"}
    )
    
    # Download each file
    $downloadSuccess = $true
    foreach ($file in $coreFiles) {
        Write-Host "Downloading: $($file.Path)" -ForegroundColor Cyan
        $result = Download-GitHubFile -RepoPath $file.Path -DestinationPath $file.Destination -Branch $Branch
        if (-not $result) {
            $downloadSuccess = $false
        }
    }
    
    # If download failed, create minimal stub files
    if (-not $downloadSuccess) {
        Write-Host "Some files could not be downloaded from GitHub. Creating minimal stub files..." -ForegroundColor Yellow
        
        # Create minimal __init__.py files
        Set-Content -Path "$InstallPath\__init__.py" -Value ""
        Set-Content -Path "$InstallPath\AccessWatch\__init__.py" -Value ""
        Set-Content -Path "$InstallPath\DriftGuardEngine\__init__.py" -Value ""
        Set-Content -Path "$InstallPath\reporting_engine\__init__.py" -Value ""
        
        # Create minimal requirements.txt
        $requirementsContent = @"
# Core requirements
requests>=2.28.0
msal>=1.20.0
pandas>=1.5.0
matplotlib>=3.6.0

# Reporting
jinja2>=3.1.2
markdown>=3.4.0
plotly>=5.9.0

# Vector database and embeddings
numpy>=1.23.0

# Date handling
python-dateutil>=2.8.2

# Utilities
colorlog>=6.7.0
"@
        Set-Content -Path "$InstallPath\requirements.txt" -Value $requirementsContent
    }
    
    # Create Run-SecurityAssessment.ps1
    Write-Host "Creating Run-SecurityAssessment.ps1..." -ForegroundColor Cyan
    $securityAssessmentContent = @'
<#
.SYNOPSIS
    Runs a comprehensive security assessment using SecurePulse and optionally SCuBA
.DESCRIPTION
    This script runs security assessments on Microsoft 365 tenant using SecurePulse modules
    and optionally SCuBA baseline checks. Results are combined into a single comprehensive report.
.PARAMETER TenantId
    The Microsoft 365 tenant ID to assess
.PARAMETER ClientId
    The application (client) ID for Microsoft Graph API access
.PARAMETER ClientSecret
    The client secret for Microsoft Graph API access
.PARAMETER UseScuba
    If specified, also runs SCuBA assessment
.PARAMETER OutputPath
    The path where reports should be saved. Defaults to "./reports"
.PARAMETER ModulesToRun
    Comma-separated list of modules to run. Options: DriftGuard,AccessWatch,LicenseLogic
    Default: all modules
.EXAMPLE
    .\Run-SecurityAssessment.ps1 -TenantId "1a2b3c4d-1234-5678-9012-abc123def456" -ClientId "app-id" -ClientSecret "app-secret"
.EXAMPLE
    .\Run-SecurityAssessment.ps1 -TenantId "1a2b3c4d-1234-5678-9012-abc123def456" -ClientId "app-id" -ClientSecret "app-secret" -UseScuba
.NOTES
    Author: Open Door MSP
    Version: 1.2.0
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [string]$TenantId,
    
    [Parameter(Mandatory=$true)]
    [string]$ClientId,
    
    [Parameter(Mandatory=$true)]
    [string]$ClientSecret,
    
    [Parameter(Mandatory=$false)]
    [switch]$UseScuba,
    
    [Parameter(Mandatory=$false)]
    [string]$OutputPath = ".\reports",
    
    [Parameter(Mandatory=$false)]
    [string]$ModulesToRun = "DriftGuard,AccessWatch,LicenseLogic"
)

$ErrorActionPreference = "Stop"
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# Ensure output directory exists
if (-not (Test-Path -Path $OutputPath)) {
    New-Item -Path $OutputPath -ItemType Directory -Force | Out-Null
}

# Set environment variables for SecurePulse
$env:MS_CLIENT_ID = $ClientId
$env:MS_CLIENT_SECRET = $ClientSecret
$env:MS_TENANT_ID = $TenantId

try {
    # Step 1: Run SecurePulse assessment
    Write-Host "Running SecurePulse modules..." -ForegroundColor Cyan
    Push-Location $scriptDir
    
    # Activate virtual environment and run SecurePulse
    $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
    
    # Run the verified modules
    if (Test-Path -Path ".\venv\Scripts\python.exe") {
        # Use virtual environment if it exists
        & .\venv\Scripts\python.exe run_verified_modules.py --modules $ModulesToRun
    } else {
        # Otherwise use system Python
        python run_verified_modules.py --modules $ModulesToRun
    }
    
    # Find the most recent results file
    $recentResultsFile = Get-ChildItem -Path ".\verified_scan\verified_scan_results_*.json" | 
                        Sort-Object LastWriteTime -Descending | 
                        Select-Object -First 1
    
    if ($recentResultsFile) {
        Write-Host "SecurePulse assessment completed successfully" -ForegroundColor Green
        Write-Host "Results saved to: $recentResultsFile" -ForegroundColor Green
    } else {
        Write-Host "Warning: Could not find SecurePulse results file" -ForegroundColor Yellow
    }
    
    # Step 2: Run SCuBA assessment if requested
    if ($UseScuba) {
        Write-Host "Running SCuBA assessment..." -ForegroundColor Cyan
        
        # Check if ScubaGear is installed
        if (-not (Get-Module -ListAvailable -Name ScubaGear)) {
            Write-Host "SCuBA not installed. Please run the installer with -InstallScuba" -ForegroundColor Red
            return
        }
        
        # Create SCuBA output directory
        $scubaOutputPath = Join-Path $OutputPath "scuba"
        if (-not (Test-Path -Path $scubaOutputPath)) {
            New-Item -Path $scubaOutputPath -ItemType Directory -Force | Out-Null
        }
        
        # Run SCuBA assessment
        try {
            Import-Module ScubaGear
            Invoke-SCuBA -ProductNames * -OutputPath $scubaOutputPath
            Write-Host "SCuBA assessment completed successfully" -ForegroundColor Green
            
            # Import SCuBA results into SecurePulse format
            Write-Host "Importing SCuBA results into SecurePulse..." -ForegroundColor Cyan
            
            if (Test-Path -Path ".\venv\Scripts\python.exe") {
                & .\venv\Scripts\python.exe import_scuba_results.py --scuba-path $scubaOutputPath
            } else {
                python import_scuba_results.py --scuba-path $scubaOutputPath
            }
        }
        catch {
            Write-Host "Error running SCuBA assessment: $_" -ForegroundColor Red
            Write-Host "You may need to run 'Initialize-SCuBA' manually first" -ForegroundColor Yellow
        }
    }
    
    # Step 3: Generate HTML report
    Write-Host "Generating HTML report..." -ForegroundColor Cyan
    
    # Find the most recent reports
    $recentDriftReport = Get-ChildItem -Path ".\verified_scan\drift\drift_report_*.json" | 
                    Sort-Object LastWriteTime -Descending | 
                    Select-Object -First 1
                    
    $recentAccessReport = Get-ChildItem -Path ".\verified_scan\access_report_*.json" | 
                        Sort-Object LastWriteTime -Descending | 
                        Select-Object -First 1
                        
    $recentLicenseReport = Get-ChildItem -Path ".\verified_scan\license_report_*.json" | 
                        Sort-Object LastWriteTime -Descending | 
                        Select-Object -First 1
    
    # Create a simple HTML report
    $reportTimestamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $reportFile = Join-Path $OutputPath "comprehensive_report_$reportTimestamp.html"
    
    # Generate report content
    $reportContent = @"
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>SecurePulse Comprehensive Report</title>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 1200px; margin: 0 auto; padding: 20px; }
        h1, h2, h3 { color: #2c3e50; }
        .header { border-bottom: 2px solid #2c3e50; padding-bottom: 10px; margin-bottom: 20px; }
        .section { margin-bottom: 30px; border: 1px solid #ddd; padding: 15px; border-radius: 5px; }
        .tenant-info { background-color: #f8f9fa; padding: 15px; border-radius: 5px; margin-bottom: 20px; }
        .compliance-good { color: #27ae60; }
        .compliance-warning { color: #f39c12; }
        .compliance-bad { color: #e74c3c; }
        .summary-box { display: inline-block; padding: 10px; margin: 5px; background-color: #f5f5f5; border-radius: 5px; min-width: 150px; text-align: center; }
        .module-title { background-color: #2c3e50; color: white; padding: 5px 10px; border-radius: 3px; }
    </style>
</head>
<body>
    <div class="header">
        <h1>SecurePulse Comprehensive Security Report</h1>
        <p>Generated on $(Get-Date -Format "MMMM d, yyyy 'at' h:mm tt")</p>
    </div>
    
    <div class="tenant-info">
        <h2>Tenant Information</h2>
        <p>Tenant ID: $TenantId</p>
    </div>
    
    <div class="section">
        <h2><span class="module-title">Summary</span></h2>
        <p>This report combines results from multiple security assessment modules:</p>
        <ul>
"@

    if ($recentDriftReport) { $reportContent += "            <li>DriftGuard - Configuration Drift Detection</li>`n" }
    if ($recentAccessReport) { $reportContent += "            <li>AccessWatch - Identity and Access Security</li>`n" }
    if ($recentLicenseReport) { $reportContent += "            <li>LicenseLogic - License Usage Optimization</li>`n" }
    if ($UseScuba) { $reportContent += "            <li>SCuBA - CISA Secure Cloud Business Applications</li>`n" }

    $reportContent += @"
        </ul>
    </div>
"@

    # Add drift detection results if available
    if ($recentDriftReport) {
        Write-Host "Adding DriftGuard results to report..." -ForegroundColor Cyan
        
        # Read drift report
        $driftData = Get-Content -Path $recentDriftReport.FullName -Raw | ConvertFrom-Json
        
        # Calculate compliance score
        $complianceScore = $driftData.summary.overallComplianceScore
        $complianceClass = "compliance-bad"
        if ($complianceScore -ge 90) { $complianceClass = "compliance-good" }
        elseif ($complianceScore -ge 70) { $complianceClass = "compliance-warning" }
        
        $reportContent += @"
    <div class="section">
        <h2><span class="module-title">DriftGuard</span> Configuration Drift Detection</h2>
        
        <div class="summary-box">
            <h3>Overall Compliance</h3>
            <p class="$complianceClass">$($complianceScore.ToString("0.0"))%</p>
        </div>
        
        <div class="summary-box">
            <h3>Requirements</h3>
            <p>Total: $($driftData.summary.totalRequirements)</p>
            <p>Compliant: $($driftData.summary.compliantRequirements)</p>
            <p>Non-Compliant: $($driftData.summary.nonCompliantRequirements)</p>
        </div>
        
        <h3>Workload Compliance</h3>
        <ul>
"@

        # Add workload compliance
        foreach ($workload in $driftData.workloads.PSObject.Properties) {
            $workloadName = $workload.Name
            $workloadScore = $workload.Value.complianceScore
            
            $workloadClass = "compliance-bad"
            if ($workloadScore -ge 90) { $workloadClass = "compliance-good" }
            elseif ($workloadScore -ge 70) { $workloadClass = "compliance-warning" }
            
            $reportContent += "            <li>$workloadName: <span class=`"$workloadClass`">$($workloadScore.ToString("0.0"))%</span></li>`n"
        }

        $reportContent += @"
        </ul>
        
        <h3>Top Issues</h3>
        <ul>
"@

        # Add top 5 non-compliant issues
        $topIssues = $driftData.driftDetails | Where-Object { $_.status -eq "Non-Compliant" } | Select-Object -First 5
        
        foreach ($issue in $topIssues) {
            $reportContent += "            <li><strong>$($issue.title)</strong> - $($issue.description)</li>`n"
        }

        $reportContent += @"
        </ul>
    </div>
"@
    }

    # Add AccessWatch results if available
    if ($recentAccessReport) {
        Write-Host "Adding AccessWatch results to report..." -ForegroundColor Cyan
        
        # Read access report
        $accessData = Get-Content -Path $recentAccessReport.FullName -Raw | ConvertFrom-Json
        
        # Calculate MFA score
        $mfaScore = $accessData.mfaCompliance.mfaAdoptionRate
        $mfaClass = "compliance-bad"
        if ($mfaScore -ge 90) { $mfaClass = "compliance-good" }
        elseif ($mfaScore -ge 70) { $mfaClass = "compliance-warning" }
        
        $reportContent += @"
    <div class="section">
        <h2><span class="module-title">AccessWatch</span> Identity and Access Security</h2>
        
        <div class="summary-box">
            <h3>MFA Adoption</h3>
            <p class="$mfaClass">$($mfaScore.ToString("0.0"))%</p>
        </div>
        
        <div class="summary-box">
            <h3>Admin MFA</h3>
            <p>$($accessData.mfaCompliance.adminMfaAdoptionRate.ToString("0.0"))%</p>
        </div>
        
        <div class="summary-box">
            <h3>At-Risk Users</h3>
            <p>$($accessData.mfaCompliance.atRiskUsers.Count)</p>
        </div>
        
        <h3>Conditional Access Policies</h3>
        <p>MFA Policy Coverage: $($accessData.conditionalAccessAnalysis.mfaPolicyCoverage)</p>
    </div>
"@
    }

    # Add LicenseLogic results if available
    if ($recentLicenseReport) {
        Write-Host "Adding LicenseLogic results to report..." -ForegroundColor Cyan
        
        # Read license report
        $licenseData = Get-Content -Path $recentLicenseReport.FullName -Raw | ConvertFrom-Json
        
        $reportContent += @"
    <div class="section">
        <h2><span class="module-title">LicenseLogic</span> License Usage Optimization</h2>
        
        <div class="summary-box">
            <h3>Total Users</h3>
            <p>$($licenseData.metadata.totalUsers)</p>
        </div>
        
        <div class="summary-box">
            <h3>License SKUs</h3>
            <p>$($licenseData.metadata.totalSkus)</p>
        </div>
        
        <div class="summary-box">
            <h3>Optimization</h3>
            <p>Users without License: $($licenseData.metadata.usersWithNoLicense)</p>
            <p>Disabled with License: $($licenseData.metadata.disabledWithLicense)</p>
        </div>
    </div>
"@
    }
    
    # Add SCuBA results if available
    if ($UseScuba) {
        Write-Host "Adding SCuBA results to report..." -ForegroundColor Cyan
        
        # Find SCuBA-imported drift report
        $scubaDriftReport = Get-ChildItem -Path ".\verified_scan\drift\drift_report_scuba_*.json" | 
                        Sort-Object LastWriteTime -Descending | 
                        Select-Object -First 1
                        
        if ($scubaDriftReport) {
            # Read SCuBA drift report
            $scubaData = Get-Content -Path $scubaDriftReport.FullName -Raw | ConvertFrom-Json
            
            # Calculate compliance score
            $scubaScore = $scubaData.summary.overallComplianceScore
            $scubaClass = "compliance-bad"
            if ($scubaScore -ge 90) { $scubaClass = "compliance-good" }
            elseif ($scubaScore -ge 70) { $scubaClass = "compliance-warning" }
            
            $reportContent += @"
    <div class="section">
        <h2><span class="module-title">SCuBA</span> CISA Secure Cloud Business Applications</h2>
        
        <div class="summary-box">
            <h3>Overall Compliance</h3>
            <p class="$scubaClass">$($scubaScore.ToString("0.0"))%</p>
        </div>
        
        <div class="summary-box">
            <h3>Requirements</h3>
            <p>Total: $($scubaData.summary.totalRequirements)</p>
            <p>Compliant: $($scubaData.summary.compliantRequirements)</p>
            <p>Non-Compliant: $($scubaData.summary.nonCompliantRequirements)</p>
        </div>
        
        <h3>Workload Compliance</h3>
        <ul>
"@

            # Add workload compliance
            foreach ($workload in $scubaData.workloads.PSObject.Properties) {
                $workloadName = $workload.Name
                $workloadScore = $workload.Value.complianceScore
                
                $workloadClass = "compliance-bad"
                if ($workloadScore -ge 90) { $workloadClass = "compliance-good" }
                elseif ($workloadScore -ge 70) { $workloadClass = "compliance-warning" }
                
                $reportContent += "            <li>$workloadName: <span class=`"$workloadClass`">$($workloadScore.ToString("0.0"))%</span></li>`n"
            }

            $reportContent += @"
        </ul>
    </div>
"@
        } else {
            $reportContent += @"
    <div class="section">
        <h2><span class="module-title">SCuBA</span> CISA Secure Cloud Business Applications</h2>
        <p>SCuBA assessment was run, but the results could not be imported. Please check the SCuBA output directory.</p>
    </div>
"@
        }
    }

    # Close HTML report
    $reportContent += @"
    <footer>
        <p>Generated by SecurePulse - © $(Get-Date -Format "yyyy")</p>
    </footer>
</body>
</html>
"@
    
    # Save the report
    Set-Content -Path $reportFile -Value $reportContent
    
    Write-Host "Assessment complete!" -ForegroundColor Green
    Write-Host "HTML Report is available at: $reportFile" -ForegroundColor Green
    
    # Try to open the report in the default browser
    try {
        Start-Process $reportFile
    }
    catch {
        Write-Host "Report generated but could not be opened automatically. Please open it manually." -ForegroundColor Yellow
    }
    
    Pop-Location
}
catch {
    Write-Host "Error during assessment: $_" -ForegroundColor Red
}
finally {
    # Clear environment variables
    Remove-Item Env:\MS_CLIENT_ID -ErrorAction SilentlyContinue
    Remove-Item Env:\MS_CLIENT_SECRET -ErrorAction SilentlyContinue
    Remove-Item Env:\MS_TENANT_ID -ErrorAction SilentlyContinue
}
'@
    
    Set-Content -Path "$InstallPath\Run-SecurityAssessment.ps1" -Value $securityAssessmentContent
    
    # Step 4: Create and setup Python virtual environment
    Write-Host "Step 4: Setting up Python environment..." -ForegroundColor Cyan
    
    $pythonEnvSuccess = $true
    
    try {
        if (-not (Test-Path -Path ".\venv")) {
            Write-Host "Creating Python virtual environment..." -ForegroundColor Cyan
            try {
                python -m venv venv
                Start-Sleep -Seconds 2  # Wait for virtual environment to initialize
            }
            catch {
                Write-Host "Error creating virtual environment: $_" -ForegroundColor Yellow
                Write-Host "Trying alternative approach..." -ForegroundColor Yellow
                try {
                    # Try with full path to python executable
                    $pythonPath = (Get-Command python).Source
                    Start-Process -FilePath $pythonPath -ArgumentList "-m", "venv", "venv" -Wait -NoNewWindow
                    Start-Sleep -Seconds 2
                }
                catch {
                    Write-Host "Could not create virtual environment. Will use system Python instead." -ForegroundColor Yellow
                    $pythonEnvSuccess = $false
                }
            }
        }
        
        Write-Host "Installing Python dependencies..." -ForegroundColor Cyan
        
        # Determine which Python to use
        if ($pythonEnvSuccess -and (Test-Path -Path ".\venv\Scripts\python.exe")) {
            $pipCommand = ".\venv\Scripts\python.exe -m pip"
            $pythonCommand = ".\venv\Scripts\python.exe"
        }
        else {
            # Fallback to system Python
            $pythonPath = (Get-Command python -ErrorAction SilentlyContinue).Source
            if ($pythonPath) {
                $pythonDir = Split-Path -Parent $pythonPath
                $pipCommand = "$pythonDir\python.exe -m pip"
                $pythonCommand = "$pythonDir\python.exe"
            }
            else {
                Write-Host "Python not found in PATH. Skipping dependency installation." -ForegroundColor Yellow
                $pythonEnvSuccess = $false
            }
        }
        
        # Install dependencies if we have Python
        if ($pythonEnvSuccess) {
            # Try to upgrade pip first - but don't fail if it doesn't work
            try {
                Invoke-Expression "$pipCommand install --upgrade pip" 
            }
            catch {
                Write-Host "Couldn't upgrade pip, but continuing with installation." -ForegroundColor Yellow
            }
            
            # Install the requirements
            try {
                Invoke-Expression "$pipCommand install -r $InstallPath\requirements.txt"
                Write-Host "Python dependencies installed successfully." -ForegroundColor Green
            }
            catch {
                Write-Host "Error installing dependencies: $_" -ForegroundColor Yellow
                Write-Host "Some features may not work correctly." -ForegroundColor Yellow
                
                # Try installing minimal dependencies
                try {
                    Invoke-Expression "$pipCommand install requests msal jinja2 markdown"
                    Write-Host "Minimal dependencies installed successfully." -ForegroundColor Yellow
                }
                catch {
                    Write-Host "Failed to install even minimal dependencies. SecurePulse may not function correctly." -ForegroundColor Red
                }
            }
        }
    }
    catch {
        Write-Host "Error setting up Python environment: $_" -ForegroundColor Yellow
        Write-Host "Will continue installation, but some features may not work correctly." -ForegroundColor Yellow
        $pythonEnvSuccess = $false
    }
    
    # Step 5: Install SCuBA if requested
    if ($InstallScuba) {
        Write-Host "Step 5: Installing SCuBA..." -ForegroundColor Cyan
        
        # Create SCuBA directory
        $scubaDir = "$InstallPath\SCuBA"
        if (-not (Test-Path -Path $scubaDir)) {
            New-Item -Path $scubaDir -ItemType Directory -Force | Out-Null
        }
        
        # Install required PowerShell modules
        Write-Host "Installing required PowerShell modules..." -ForegroundColor Cyan
        Set-PSRepository -Name PSGallery -InstallationPolicy Trusted
        
        Write-Host "Installing PowerShellGet..." -ForegroundColor Cyan
        Install-Module -Name PowerShellGet -Force -AllowClobber -Scope CurrentUser
        
        Write-Host "Installing ScubaGear..." -ForegroundColor Cyan
        Install-Module -Name ScubaGear -Force -Scope CurrentUser
        
        Write-Host "Initializing SCuBA..." -ForegroundColor Cyan
        try {
            Import-Module ScubaGear
            Initialize-SCuBA
        }
        catch {
            Write-Host "Warning: Error during SCuBA initialization: $_" -ForegroundColor Yellow
            Write-Host "This may be resolved by running Initialize-SCuBA manually after installation." -ForegroundColor Yellow
        }
    }
    
    # Step 6: Create shortcuts (Start Menu and batch file)
    Write-Host "Step 6: Creating shortcuts..." -ForegroundColor Cyan
    
    # Create Start Menu shortcut
    try {
        $startMenuPath = [System.Environment]::GetFolderPath('Programs')
        $startMenuDir = "$startMenuPath\SecurePulse"
        
        if (-not (Test-Path -Path $startMenuDir)) {
            New-Item -Path $startMenuDir -ItemType Directory -Force | Out-Null
        }
        
        $WshShell = New-Object -ComObject WScript.Shell
        $Shortcut = $WshShell.CreateShortcut("$startMenuDir\SecurePulse Assessment.lnk")
        $Shortcut.TargetPath = "powershell.exe"
        $Shortcut.Arguments = "-ExecutionPolicy Bypass -File `"$InstallPath\Run-SecurityAssessment.ps1`""
        $Shortcut.WorkingDirectory = $InstallPath
        $Shortcut.IconLocation = "powershell.exe,0"
        $Shortcut.Description = "Run SecurePulse Security Assessment"
        $Shortcut.Save()
        
        Write-Host "Start Menu shortcut created successfully." -ForegroundColor Green
    }
    catch {
        Write-Host "Warning: Could not create Start Menu shortcut: $_" -ForegroundColor Yellow
        Write-Host "You can still run SecurePulse using the batch file or PowerShell script directly." -ForegroundColor Yellow
    }
    
    # Create batch file launcher (alternative to shortcuts)
    try {
        $batchContent = @"
@echo off
echo Running SecurePulse Security Assessment...
powershell.exe -ExecutionPolicy Bypass -File "$InstallPath\Run-SecurityAssessment.ps1" %*
"@
        
        Set-Content -Path "$InstallPath\Run-SecurePulse.bat" -Value $batchContent
        Write-Host "Batch file launcher created: $InstallPath\Run-SecurePulse.bat" -ForegroundColor Green
    }
    catch {
        Write-Host "Warning: Could not create batch file launcher: $_" -ForegroundColor Yellow
    }
    
    # Optional desktop shortcut - try/catch to handle potential COM failures
    try {
        $WshShell = New-Object -ComObject WScript.Shell
        $Shortcut = $WshShell.CreateShortcut("$env:USERPROFILE\Desktop\SecurePulse.lnk")
        $Shortcut.TargetPath = "powershell.exe"
        $Shortcut.Arguments = "-ExecutionPolicy Bypass -File `"$InstallPath\Run-SecurityAssessment.ps1`""
        $Shortcut.WorkingDirectory = $InstallPath
        $Shortcut.IconLocation = "powershell.exe,0"
        $Shortcut.Description = "Run SecurePulse Security Assessment"
        $Shortcut.Save()
        Write-Host "Desktop shortcut created successfully." -ForegroundColor Green
    }
    catch {
        Write-Host "Could not create desktop shortcut: $_" -ForegroundColor Yellow
        Write-Host "You can use the Start Menu or batch file instead." -ForegroundColor Yellow
    }
    
    # Step 7: Create README file
    Write-Host "Step 7: Creating documentation..." -ForegroundColor Cyan
    
    $readmeContent = @"
# SecurePulse

## Installation Complete!

SecurePulse has been successfully installed on your system.

## Ways to Launch SecurePulse

You can run SecurePulse in multiple ways:

1. **Start Menu**: Programs > SecurePulse > SecurePulse Assessment

2. **Batch File**: Run the following batch file:
   ```
   $InstallPath\Run-SecurePulse.bat
   ```

3. **PowerShell Script**: Execute directly with parameters:
   ```
   $InstallPath\Run-SecurityAssessment.ps1 -TenantId "your-tenant-id" -ClientId "your-client-id" -ClientSecret "your-client-secret"
   ```

## Usage Options

1. Run a basic security assessment:
   ```
   $InstallPath\Run-SecurityAssessment.ps1 -TenantId "your-tenant-id" -ClientId "your-client-id" -ClientSecret "your-client-secret"
   ```

2. To include SCuBA assessment, add the `-UseScuba` parameter:
   ```
   $InstallPath\Run-SecurityAssessment.ps1 -TenantId "your-tenant-id" -ClientId "your-client-id" -ClientSecret "your-client-secret" -UseScuba
   ```

3. To run specific modules only:
   ```
   $InstallPath\Run-SecurityAssessment.ps1 -TenantId "your-tenant-id" -ClientId "your-client-id" -ClientSecret "your-client-secret" -ModulesToRun "DriftGuard,AccessWatch"
   ```

4. Reports will be generated in the `reports` directory.

## Core Modules

SecurePulse includes the following core modules:

1. **DriftGuard Engine**: Detects configuration drift against security baselines
2. **AccessWatch**: Monitors conditional access policies and MFA adoption
3. **LicenseLogic**: Analyzes license utilization and optimization opportunities
4. **SCuBA Integration**: Imports CISA SCuBA assessment results (if installed)

## Troubleshooting

- If you encounter any issues, check the logs in the `$logDir` directory.
- Make sure your Microsoft Graph API credentials have the necessary permissions.
- For SCuBA-related issues, refer to the SCuBA documentation.
- If shortcuts aren't working, use the batch file or PowerShell script directly.

## Update

To update SecurePulse, run the installer again.

"@
    
    Set-Content -Path "$InstallPath\README_INSTALL.md" -Value $readmeContent
    
    # Final step: Completion message
    Write-Host "===================================================" -ForegroundColor Green
    Write-Host "Installation Complete!" -ForegroundColor Green
    Write-Host "===================================================" -ForegroundColor Green
    Write-Host "SecurePulse has been installed to: $InstallPath" -ForegroundColor Green
    Write-Host "You can launch SecurePulse in multiple ways:" -ForegroundColor Green
    Write-Host "1. Start Menu: Programs > SecurePulse > SecurePulse Assessment" -ForegroundColor Yellow
    Write-Host "2. Batch File: $InstallPath\Run-SecurePulse.bat" -ForegroundColor Yellow
    Write-Host "3. PowerShell Script:" -ForegroundColor Yellow
    Write-Host "   $InstallPath\Run-SecurityAssessment.ps1 -TenantId 'your-tenant-id' -ClientId 'your-client-id' -ClientSecret 'your-client-secret'" -ForegroundColor Yellow
    
    if ($InstallScuba) {
        Write-Host "Include SCuBA assessment with: -UseScuba" -ForegroundColor Yellow
    }
    Write-Host "See $InstallPath\README_INSTALL.md for more information." -ForegroundColor Green
    Write-Host "===================================================" -ForegroundColor Green
    
    Pop-Location
}
catch {
    Write-Host "Error during installation: $_" -ForegroundColor Red
    Write-Host "Check the log file for more details: $logFile" -ForegroundColor Red
}
finally {
    Stop-Transcript
}