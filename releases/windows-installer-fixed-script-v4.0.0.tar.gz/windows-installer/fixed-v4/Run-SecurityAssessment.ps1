<#
.SYNOPSIS
    Runs a comprehensive security assessment using SecurePulse and optionally SCuBA
.DESCRIPTION
    This script runs security assessments on Microsoft 365 tenant using SecurePulse modules
    and optionally SCuBA baseline checks. Results are combined into a single comprehensive report.
.PARAMETER TenantId
    The Microsoft 365 tenant ID to assess
.PARAMETER ClientId
    The application (client) ID for Microsoft Graph API access
.PARAMETER ClientSecret
    The client secret for Microsoft Graph API access
.PARAMETER UseScuba
    If specified, also runs SCuBA assessment
.PARAMETER OutputPath
    The path where reports should be saved. Defaults to "./reports"
.PARAMETER ModulesToRun
    Comma-separated list of modules to run. Options: DriftGuard,AccessWatch,LicenseLogic
    Default: all modules
.PARAMETER WaitTimeScuba
    Number of seconds to wait for SCuBA to complete. Defaults to 900 (15 minutes).
.PARAMETER DetailedReport
    If specified, includes detailed tables of users and their configuration in the report.
.EXAMPLE
    .\Run-SecurityAssessment.ps1 -TenantId "1a2b3c4d-1234-5678-9012-abc123def456" -ClientId "app-id" -ClientSecret "app-secret"
.EXAMPLE
    .\Run-SecurityAssessment.ps1 -TenantId "1a2b3c4d-1234-5678-9012-abc123def456" -ClientId "app-id" -ClientSecret "app-secret" -UseScuba -DetailedReport
.NOTES
    Author: Open Door MSP
    Version: 4.0.0
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [string]$TenantId,
    
    [Parameter(Mandatory=$true)]
    [string]$ClientId,
    
    [Parameter(Mandatory=$true)]
    [string]$ClientSecret,
    
    [Parameter(Mandatory=$false)]
    [switch]$UseScuba,
    
    [Parameter(Mandatory=$false)]
    [string]$OutputPath = ".\reports",
    
    [Parameter(Mandatory=$false)]
    [string]$ModulesToRun = "DriftGuard,AccessWatch,LicenseLogic",
    
    [Parameter(Mandatory=$false)]
    [int]$WaitTimeScuba = 900,
    
    [Parameter(Mandatory=$false)]
    [switch]$DetailedReport = $true
)

$ErrorActionPreference = "Stop"
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

# Create log directory
$logDir = Join-Path $scriptDir "logs"
if (-not (Test-Path -Path $logDir)) {
    New-Item -Path $logDir -ItemType Directory -Force | Out-Null
}

# Start logging
$logFile = Join-Path $logDir "assessment_$(Get-Date -Format 'yyyyMMdd_HHmmss').log"
Start-Transcript -Path $logFile

# Function to log messages with timestamp
function Write-Log {
    param(
        [Parameter(Mandatory=$true)]
        [string]$Message,
        
        [Parameter(Mandatory=$false)]
        [string]$Color = "White"
    )
    
    $timestamp = Get-Date -Format "yyyy-MM-dd HH:mm:ss"
    Write-Host "[$timestamp] $Message" -ForegroundColor $Color
}

# Function to find latest directory in a path
function Get-LatestDirectory {
    param(
        [Parameter(Mandatory=$true)]
        [string]$Path
    )
    
    Get-ChildItem -Path $Path -Directory | Sort-Object LastWriteTime -Descending | Select-Object -First 1
}

# Function to create LicenseLogic data if it's missing
function Create-LicenseLogicData {
    param(
        [Parameter(Mandatory=$true)]
        [string]$OutputPath
    )
    
    Write-Log "Generating LicenseLogic data directly from Microsoft Graph..." -Color Cyan
    
    try {
        # Connect to Microsoft Graph
        Write-Log "Connecting to Microsoft Graph..." -Color Cyan
        $securePassword = ConvertTo-SecureString $ClientSecret -AsPlainText -Force
        $clientSecretCredential = New-Object System.Management.Automation.PSCredential($ClientId, $securePassword)
        
        # Import Microsoft Graph module if available
        if (-not (Get-Module -ListAvailable -Name Microsoft.Graph.Users)) {
            Write-Log "Installing Microsoft Graph Users module..." -Color Cyan
            Install-Module Microsoft.Graph.Users -Scope CurrentUser -Force
        }
        
        if (-not (Get-Module -ListAvailable -Name Microsoft.Graph.Authentication)) {
            Write-Log "Installing Microsoft Graph Authentication module..." -Color Cyan
            Install-Module Microsoft.Graph.Authentication -Scope CurrentUser -Force
        }
        
        # Connect to Microsoft Graph
        Connect-MgGraph -ClientSecretCredential $clientSecretCredential -TenantId $TenantId
        
        # Get all users
        Write-Log "Getting users from Microsoft Graph..." -Color Cyan
        $users = Get-MgUser -All -Property Id, DisplayName, UserPrincipalName, AccountEnabled, AssignedLicenses, UserType
        
        # Get license SKUs
        Write-Log "Getting license SKUs from Microsoft Graph..." -Color Cyan
        $subscriptions = Get-MgSubscribedSku
        
        # Create license lookup dictionary
        $licenseLookup = @{}
        foreach ($sub in $subscriptions) {
            $licenseLookup[$sub.SkuId] = $sub.SkuPartNumber
        }
        
        # Process user licenses
        $userLicenses = @()
        $totalUsers = $users.Count
        $usersWithNoLicense = 0
        $disabledWithLicense = 0
        
        foreach ($user in $users) {
            $isLicensed = $user.AssignedLicenses.Count -gt 0
            $isEnabled = $user.AccountEnabled
            
            if (-not $isLicensed) {
                $usersWithNoLicense++
            }
            
            if (-not $isEnabled -and $isLicensed) {
                $disabledWithLicense++
            }
            
            $licenses = @()
            foreach ($license in $user.AssignedLicenses) {
                $licenseName = $licenseLookup[$license.SkuId]
                if ($licenseName) {
                    $licenses += $licenseName
                }
            }
            
            $userLicenses += [PSCustomObject]@{
                UserPrincipalName = $user.UserPrincipalName
                DisplayName = $user.DisplayName
                IsEnabled = $isEnabled
                IsLicensed = $isLicensed
                Licenses = $licenses -join ", "
                OptimizationNeeded = (-not $isEnabled -and $isLicensed) -or ($user.UserType -eq "Guest" -and $isLicensed)
                OptimizationReason = if (-not $isEnabled -and $isLicensed) { "Disabled account with license" } elseif ($user.UserType -eq "Guest" -and $isLicensed) { "Guest account with license" } else { "" }
            }
        }
        
        # Create license report
        $licenseReport = [PSCustomObject]@{
            metadata = [PSCustomObject]@{
                totalUsers = $totalUsers
                totalSkus = $subscriptions.Count
                usersWithNoLicense = $usersWithNoLicense
                disabledWithLicense = $disabledWithLicense
                reportDate = (Get-Date).ToString("o")
            }
            licenses = $subscriptions | ForEach-Object {
                [PSCustomObject]@{
                    skuId = $_.SkuId
                    skuPartNumber = $_.SkuPartNumber
                    consumedUnits = $_.ConsumedUnits
                    prepaidUnits = $_.PrepaidUnits
                }
            }
            userLicenses = $userLicenses
        }
        
        # Create output directory if it doesn't exist
        $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
        $verifiedScanDir = Join-Path $scriptDir "verified_scan"
        if (-not (Test-Path -Path $verifiedScanDir)) {
            New-Item -Path $verifiedScanDir -ItemType Directory -Force | Out-Null
        }
        
        # Save license report
        $licenseReportPath = Join-Path $verifiedScanDir "license_report_$timestamp.json"
        $licenseReport | ConvertTo-Json -Depth 10 | Set-Content -Path $licenseReportPath
        
        Write-Log "LicenseLogic data generated and saved to: $licenseReportPath" -Color Green
        
        return $licenseReportPath
    }
    catch {
        Write-Log "ERROR generating LicenseLogic data: $_" -Color Red
        Write-Log "Error details:" -Color Red
        Write-Log $_.Exception -Color Red
        Write-Log $_.ScriptStackTrace -Color Red
        return $null
    }
    finally {
        # Disconnect from Microsoft Graph
        Disconnect-MgGraph -ErrorAction SilentlyContinue
    }
}

# Ensure output directory exists
if (-not (Test-Path -Path $OutputPath)) {
    New-Item -Path $OutputPath -ItemType Directory -Force | Out-Null
}

# Set environment variables for SecurePulse
$env:MS_CLIENT_ID = $ClientId
$env:MS_CLIENT_SECRET = $ClientSecret
$env:MS_TENANT_ID = $TenantId

try {
    Write-Log "Starting security assessment for tenant: $TenantId" -Color Cyan
    Write-Log "Log file: $logFile" -Color Cyan
    
    # Step 1: Run SCuBA assessment first if requested
    if ($UseScuba) {
        Write-Log "============ STARTING SCUBA ASSESSMENT ============" -Color Cyan
        Push-Location $scriptDir
        
        # Check if ScubaGear is installed
        if (-not (Get-Module -ListAvailable -Name ScubaGear)) {
            Write-Log "ERROR: SCuBA not installed. Please run the installer with -InstallScuba" -Color Red
            throw "SCuBA module not installed"
        }
        
        # Run SCuBA assessment
        try {
            Write-Log "Importing ScubaGear module..." -Color Cyan
            Import-Module ScubaGear
            
            Write-Log "Running Initialize-SCuBA to ensure proper setup..." -Color Cyan
            try {
                # Initialize SCuBA first
                Initialize-SCuBA -Force
                Write-Log "SCuBA initialized successfully" -Color Green
            }
            catch {
                Write-Log "WARNING: Error during SCuBA initialization: $_" -Color Yellow
                Write-Log "Continuing anyway, as initialization may have already been completed" -Color Yellow
            }
            
            # Create directory for SCuBA output
            $scubaBaseDir = Join-Path $scriptDir "Scuba"
            if (-not (Test-Path -Path $scubaBaseDir)) {
                New-Item -Path $scubaBaseDir -ItemType Directory -Force | Out-Null
            }
            
            Write-Log "Running Invoke-SCuBA..." -Color Cyan
            Write-Log "This process can take several minutes (15-30 minutes). Please wait..." -Color Yellow
            Write-Log "Current time: $(Get-Date)" -Color Cyan
            
            # Get SCuBA parameters first
            Write-Log "Getting help for Invoke-SCuBA to determine parameters..." -Color Cyan
            $scubaHelp = Get-Help Invoke-SCuBA -Full
            Write-Log "SCuBA command syntax: $($scubaHelp.Syntax)" -Color Cyan
            
            # Run SCuBA with the correct parameters based on the version
            # The default command with most likely parameters
            $scubaParams = @{
                ProductNames = @("*")
            }
            
            # Set credentials for SCuBA
            if ($TenantId -and $ClientId -and $ClientSecret) {
                $securePassword = ConvertTo-SecureString $ClientSecret -AsPlainText -Force
                $appCredential = New-Object System.Management.Automation.PSCredential($ClientId, $securePassword)
                $scubaParams.M365Environment = @{
                    TenantId = $TenantId
                    AppCredential = $appCredential
                }
            }
            
            Write-Log "Running SCuBA assessment with parameters: $($scubaParams | ConvertTo-Json -Depth 2)" -Color Cyan
            
            # Run the actual SCuBA command
            Write-Host "Invoking Invoke-SCuBA, this will take 15-30 minutes..."
            
            Invoke-SCuBA @scubaParams
            
            Write-Log "SCuBA assessment completed at: $(Get-Date)" -Color Green
            
            # Find the actual SCuBA output path
            Write-Log "Looking for SCuBA output directory..." -Color Cyan
            $scubaOutputDirs = @(
                (Join-Path $scriptDir "M365BaselineConformance"),
                (Join-Path $scriptDir "Scuba"),
                (Join-Path $env:USERPROFILE "Documents\ScubaGear"),
                "C:\ScubaGear"
            )
            
            $scubaOutputPath = $null
            foreach ($dir in $scubaOutputDirs) {
                if (Test-Path $dir) {
                    Write-Log "Found potential SCuBA output directory: $dir" -Color Cyan
                    $scubaOutputPath = $dir
                    break
                }
            }
            
            if (-not $scubaOutputPath) {
                Write-Log "WARNING: Could not find SCuBA output directory" -Color Yellow
                # Look for any directories that might contain SCuBA output
                $potentialDirs = Get-ChildItem -Path $scriptDir -Directory | Where-Object { $_.Name -match "Scuba|M365|Baseline|Results" }
                if ($potentialDirs.Count -gt 0) {
                    $scubaOutputPath = $potentialDirs[0].FullName
                    Write-Log "Using potential SCuBA directory: $scubaOutputPath" -Color Yellow
                }
            }
            
            # Ensure SCuBA results exist before continuing
            $resultsFound = $false
            $scubaDirs = @()
            $waitStart = Get-Date
            $maxWaitTime = New-TimeSpan -Seconds $WaitTimeScuba
            
            Write-Log "Waiting for SCuBA results to be available (max $WaitTimeScuba seconds)..." -Color Yellow
            
            do {
                # Check for SCuBA assessment directories in multiple locations
                foreach ($dir in $scubaOutputDirs) {
                    if (Test-Path $dir) {
                        $subDirs = Get-ChildItem -Path $dir -Directory -ErrorAction SilentlyContinue
                        foreach ($subDir in $subDirs) {
                            $resultsPath = Join-Path $subDir.FullName "Results\results.json"
                            if (Test-Path $resultsPath) {
                                $scubaDirs += @{
                                    Dir = $subDir.FullName
                                    ResultsPath = $resultsPath
                                    LastWrite = (Get-Item $resultsPath).LastWriteTime
                                }
                            }
                        }
                    }
                }
                
                if ($scubaDirs.Count -gt 0) {
                    # Sort by last write time to get the most recent
                    $latestResults = $scubaDirs | Sort-Object -Property LastWrite -Descending | Select-Object -First 1
                    $resultsFound = $true
                    Write-Log "SCuBA results found at: $($latestResults.ResultsPath)" -Color Green
                    break
                }
                
                # Check if maximum wait time has been exceeded
                $elapsed = (Get-Date) - $waitStart
                if ($elapsed -gt $maxWaitTime) {
                    Write-Log "WARNING: Timeout waiting for SCuBA results. Proceeding anyway." -Color Yellow
                    break
                }
                
                Write-Log "SCuBA results not yet available. Waiting 30 seconds... (Elapsed: $($elapsed.TotalSeconds) seconds)" -Color Yellow
                Start-Sleep -Seconds 30
                
            } while (-not $resultsFound)
            
            # Import SCuBA results into SecurePulse format
            if ($resultsFound) {
                Write-Log "Importing SCuBA results into SecurePulse format..." -Color Cyan
                $latestResultsDir = $latestResults.Dir
                $latestResultsPath = $latestResults.ResultsPath
                
                Write-Log "Latest SCuBA assessment directory: $latestResultsDir" -Color Cyan
                Write-Log "Latest SCuBA results file: $latestResultsPath" -Color Cyan
                
                # Create verified_scan directory if not exists
                $verifiedScanDir = Join-Path $scriptDir "verified_scan"
                if (-not (Test-Path -Path $verifiedScanDir)) {
                    New-Item -Path $verifiedScanDir -ItemType Directory -Force | Out-Null
                }
                
                $driftDir = Join-Path $verifiedScanDir "drift"
                if (-not (Test-Path -Path $driftDir)) {
                    New-Item -Path $driftDir -ItemType Directory -Force | Out-Null
                }
                
                # Copy SCuBA results to a folder we can use
                $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
                $scubaImportDir = Join-Path $scriptDir "scuba_import_$timestamp"
                if (-not (Test-Path -Path $scubaImportDir)) {
                    New-Item -Path $scubaImportDir -ItemType Directory -Force | Out-Null
                }
                
                # Copy results file for import
                Copy-Item -Path $latestResultsPath -Destination "$scubaImportDir\results.json" -Force
                
                # Run import script
                if (Test-Path -Path ".\venv\Scripts\python.exe") {
                    & .\venv\Scripts\python.exe import_scuba_results.py --scuba-path $scubaImportDir
                } else {
                    python import_scuba_results.py --scuba-path $scubaImportDir
                }
                
                # Clean up temporary directory
                Remove-Item -Path $scubaImportDir -Recurse -Force -ErrorAction SilentlyContinue
                
                # Verify import was successful
                $scubaDriftReport = Get-ChildItem -Path ".\verified_scan\drift\drift_report_scuba_*.json" | 
                                    Sort-Object LastWriteTime -Descending | 
                                    Select-Object -First 1
                
                if ($scubaDriftReport) {
                    Write-Log "SCuBA results have been successfully imported: $($scubaDriftReport.FullName)" -Color Green
                } else {
                    Write-Log "WARNING: SCuBA results import may have failed. No drift report found." -Color Yellow
                    
                    # Try direct import
                    Write-Log "Attempting direct import of SCuBA results..." -Color Yellow
                    
                    try {
                        # Read SCuBA results JSON
                        $scubaResults = Get-Content -Path $latestResultsPath -Raw | ConvertFrom-Json
                        
                        # Create a minimal drift report
                        $driftReport = @{
                            reportDate = (Get-Date).ToString("o")
                            tenantName = "SCuBA Assessment"
                            tenantId = $TenantId
                            summary = @{
                                totalRequirements = 0
                                compliantRequirements = 0
                                nonCompliantRequirements = 0
                                unknownRequirements = 0
                                overallComplianceScore = 0.0
                            }
                            workloads = @{}
                            driftDetails = @()
                        }
                        
                        # Process products
                        foreach ($product in $scubaResults.products) {
                            $productName = $product.productName.ToLower()
                            $driftReport.workloads[$productName] = @{
                                totalRequirements = 0
                                compliantRequirements = 0
                                nonCompliantRequirements = 0
                                unknownRequirements = 0
                                complianceScore = 0.0
                            }
                            
                            foreach ($control in $product.controls) {
                                $isCompliant = $control.controlResult
                                
                                # Update counters
                                $driftReport.summary.totalRequirements++
                                $driftReport.workloads[$productName].totalRequirements++
                                
                                if ($isCompliant) {
                                    $driftReport.summary.compliantRequirements++
                                    $driftReport.workloads[$productName].compliantRequirements++
                                } else {
                                    $driftReport.summary.nonCompliantRequirements++
                                    $driftReport.workloads[$productName].nonCompliantRequirements++
                                }
                                
                                # Add detail
                                $driftReport.driftDetails += @{
                                    requirementId = $control.controlId
                                    workload = $productName
                                    title = $control.controlName
                                    status = if ($isCompliant) { "Compliant" } else { "Non-Compliant" }
                                    description = $control.description
                                    impact = "Medium"
                                    requiredValue = $null
                                    currentValue = $null
                                    remediation = $control.remediation
                                }
                            }
                            
                            # Calculate compliance score
                            if ($driftReport.workloads[$productName].totalRequirements -gt 0) {
                                $driftReport.workloads[$productName].complianceScore = 
                                    100 * $driftReport.workloads[$productName].compliantRequirements / $driftReport.workloads[$productName].totalRequirements
                            }
                        }
                        
                        # Calculate overall compliance score
                        if ($driftReport.summary.totalRequirements -gt 0) {
                            $driftReport.summary.overallComplianceScore = 
                                100 * $driftReport.summary.compliantRequirements / $driftReport.summary.totalRequirements
                        }
                        
                        # Save drift report
                        $scubaDriftReportPath = Join-Path $driftDir "drift_report_scuba_$timestamp.json"
                        $driftReport | ConvertTo-Json -Depth 10 | Set-Content -Path $scubaDriftReportPath
                        
                        Write-Log "Direct SCuBA import successful: $scubaDriftReportPath" -Color Green
                    }
                    catch {
                        Write-Log "ERROR: Direct SCuBA import failed: $_" -Color Red
                    }
                }
            } else {
                Write-Log "WARNING: Could not find SCuBA results after waiting. The import step will be skipped." -Color Yellow
                Write-Log "Please check the following locations for SCuBA results:" -Color Yellow
                foreach ($dir in $scubaOutputDirs) {
                    Write-Log "- $dir" -Color Yellow
                }
            }
        }
        catch {
            Write-Log "ERROR running SCuBA assessment: $_" -Color Red
            
            # Get more details about the error
            Write-Log "Error details:" -Color Red
            Write-Log $_.Exception -Color Red
            Write-Log $_.ScriptStackTrace -Color Red
            
            Write-Log "You may need to run 'Initialize-SCuBA' manually first." -Color Yellow
            Write-Log "Continuing with SecurePulse modules..." -Color Yellow
        }
        
        Write-Log "============ COMPLETED SCUBA ASSESSMENT ============" -Color Cyan
    }
    
    # Step 2: Run SecurePulse assessment
    Write-Log "============ STARTING SECUREPULSE MODULES ============" -Color Cyan
    Push-Location $scriptDir
    
    # Activate virtual environment and run SecurePulse
    $timestamp = Get-Date -Format "yyyyMMdd_HHmmss"
    
    # Run the verified modules with error handling
    try {
        Write-Log "Running SecurePulse modules: $ModulesToRun" -Color Cyan
        Write-Log "This process can take several minutes. Please wait..." -Color Yellow
        Write-Log "Current time: $(Get-Date)" -Color Cyan
        
        if (Test-Path -Path ".\venv\Scripts\python.exe") {
            # Use virtual environment if it exists
            & .\venv\Scripts\python.exe run_verified_modules.py --modules $ModulesToRun
        } else {
            # Otherwise use system Python
            python run_verified_modules.py --modules $ModulesToRun
        }
        
        Write-Log "SecurePulse modules completed at: $(Get-Date)" -Color Green
    }
    catch {
        Write-Log "ERROR running SecurePulse modules: $_" -Color Red
        Write-Log "This might be due to missing dependencies or configuration issues." -Color Yellow
        Write-Log "The report will still be generated with available data." -Color Yellow
    }
    
    # Find the most recent results file
    $recentResultsFile = Get-ChildItem -Path ".\verified_scan\verified_scan_results_*.json" -ErrorAction SilentlyContinue | 
                        Sort-Object LastWriteTime -Descending | 
                        Select-Object -First 1
    
    if ($recentResultsFile) {
        Write-Log "SecurePulse assessment completed successfully" -Color Green
        Write-Log "Results saved to: $($recentResultsFile.FullName)" -Color Green
    } else {
        Write-Log "WARNING: Could not find SecurePulse results file" -Color Yellow
    }
    
    Write-Log "============ COMPLETED SECUREPULSE MODULES ============" -Color Cyan
    
    # Step 3: Generate HTML report
    Write-Log "============ GENERATING HTML REPORT ============" -Color Cyan
    
    # Find the most recent reports
    $recentDriftReport = Get-ChildItem -Path ".\verified_scan\drift\drift_report_*.json" -ErrorAction SilentlyContinue | 
                    Where-Object { $_.Name -notmatch 'scuba' } |
                    Sort-Object LastWriteTime -Descending | 
                    Select-Object -First 1
                    
    $recentAccessReport = Get-ChildItem -Path ".\verified_scan\access_report_*.json" -ErrorAction SilentlyContinue | 
                        Sort-Object LastWriteTime -Descending | 
                        Select-Object -First 1
                        
    $recentLicenseReport = Get-ChildItem -Path ".\verified_scan\license_report_*.json" -ErrorAction SilentlyContinue | 
                        Sort-Object LastWriteTime -Descending | 
                        Select-Object -First 1
    
    # Find SCuBA-imported drift report
    $scubaDriftReport = $null
    if ($UseScuba) {
        $scubaDriftReport = Get-ChildItem -Path ".\verified_scan\drift\drift_report_scuba_*.json" -ErrorAction SilentlyContinue | 
                        Sort-Object LastWriteTime -Descending | 
                        Select-Object -First 1
    }
    
    # If LicenseLogic report is not available, try to generate directly
    if ($null -eq $recentLicenseReport -and $ModulesToRun -match "LicenseLogic") {
        Write-Log "LicenseLogic report not found. Trying to generate directly..." -Color Yellow
        $licenseReportPath = Create-LicenseLogicData -OutputPath $OutputPath
        if ($licenseReportPath) {
            $recentLicenseReport = Get-Item $licenseReportPath
        }
    }
    
    # Log available report files
    Write-Log "Available reports for generation:" -Color Cyan
    if ($recentDriftReport) { Write-Log "- DriftGuard: $($recentDriftReport.FullName)" -Color Green }
    if ($recentAccessReport) { Write-Log "- AccessWatch: $($recentAccessReport.FullName)" -Color Green }
    if ($recentLicenseReport) { Write-Log "- LicenseLogic: $($recentLicenseReport.FullName)" -Color Green }
    if ($scubaDriftReport) { Write-Log "- SCuBA: $($scubaDriftReport.FullName)" -Color Green }
    
    # Create a simple HTML report
    $reportTimestamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $reportFile = Join-Path $OutputPath "comprehensive_report_$reportTimestamp.html"
    
    # Generate report content
    $reportContent = @"
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>SecurePulse Comprehensive Report</title>
    <style>
        body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 1200px; margin: 0 auto; padding: 20px; }
        h1, h2, h3 { color: #2c3e50; }
        .header { border-bottom: 2px solid #2c3e50; padding-bottom: 10px; margin-bottom: 20px; }
        .section { margin-bottom: 30px; border: 1px solid #ddd; padding: 15px; border-radius: 5px; }
        .tenant-info { background-color: #f8f9fa; padding: 15px; border-radius: 5px; margin-bottom: 20px; }
        .compliance-good { color: #27ae60; }
        .compliance-warning { color: #f39c12; }
        .compliance-bad { color: #e74c3c; }
        .summary-box { display: inline-block; padding: 10px; margin: 5px; background-color: #f5f5f5; border-radius: 5px; min-width: 150px; text-align: center; }
        .module-title { background-color: #2c3e50; color: white; padding: 5px 10px; border-radius: 3px; }
        table { border-collapse: collapse; width: 100%; margin-top: 20px; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        tr:nth-child(even) { background-color: #f9f9f9; }
        .details-table { max-height: 400px; overflow-y: auto; margin-top: 20px; }
        .user-yes { color: #27ae60; }
        .user-no { color: #e74c3c; }
        .user-admin { font-weight: bold; color: #3498db; }
        .user-warning { background-color: #fffbe6; }
        button.collapsible { background-color: #f1f1f1; color: #444; cursor: pointer; padding: 18px; width: 100%; border: none; text-align: left; outline: none; font-size: 15px; margin-top: 10px; border-radius: 5px; }
        button.collapsible:after { content: '\002B'; color: #777; font-weight: bold; float: right; margin-left: 5px; }
        button.active:after { content: "\2212"; }
        button.collapsible:hover { background-color: #ddd; }
        .content { padding: 0 18px; max-height: 0; overflow: hidden; transition: max-height 0.2s ease-out; background-color: #f9f9f9; }
    </style>
</head>
<body>
    <div class="header">
        <h1>SecurePulse Comprehensive Security Report</h1>
        <p>Generated on $(Get-Date -Format "MMMM d, yyyy 'at' h:mm tt")</p>
    </div>
    
    <div class="tenant-info">
        <h2>Tenant Information</h2>
        <p>Tenant ID: $TenantId</p>
    </div>
    
    <div class="section">
        <h2><span class="module-title">Summary</span></h2>
        <p>This report combines results from multiple security assessment modules:</p>
        <ul>
"@

    if ($recentDriftReport) { $reportContent += "            <li>DriftGuard - Configuration Drift Detection</li>`n" }
    if ($recentAccessReport) { $reportContent += "            <li>AccessWatch - Identity and Access Security</li>`n" }
    if ($recentLicenseReport) { $reportContent += "            <li>LicenseLogic - License Usage Optimization</li>`n" }
    if ($scubaDriftReport) { $reportContent += "            <li>SCuBA - CISA Secure Cloud Business Applications</li>`n" }
    if (-not ($recentDriftReport -or $recentAccessReport -or $recentLicenseReport -or $scubaDriftReport)) {
        $reportContent += "            <li>No assessment modules completed successfully</li>`n"
    }

    $reportContent += @"
        </ul>
    </div>
"@

    # Add drift detection results if available
    if ($recentDriftReport) {
        Write-Log "Adding DriftGuard results to report..." -Color Cyan
        
        # Read drift report
        $driftData = Get-Content -Path $recentDriftReport.FullName -Raw | ConvertFrom-Json
        
        # Calculate compliance score
        $complianceScore = $driftData.summary.overallComplianceScore
        $complianceClass = "compliance-bad"
        if ($complianceScore -ge 90) { $complianceClass = "compliance-good" }
        elseif ($complianceScore -ge 70) { $complianceClass = "compliance-warning" }
        
        $reportContent += @"
    <div class="section">
        <h2><span class="module-title">DriftGuard</span> Configuration Drift Detection</h2>
        
        <div class="summary-box">
            <h3>Overall Compliance</h3>
            <p class="$complianceClass">$($complianceScore.ToString("0.0"))%</p>
        </div>
        
        <div class="summary-box">
            <h3>Requirements</h3>
            <p>Total: $($driftData.summary.totalRequirements)</p>
            <p>Compliant: $($driftData.summary.compliantRequirements)</p>
            <p>Non-Compliant: $($driftData.summary.nonCompliantRequirements)</p>
        </div>
        
        <h3>Workload Compliance</h3>
        <ul>
"@

        # Add workload compliance
        foreach ($workload in $driftData.workloads.PSObject.Properties) {
            $wName = $workload.Name
            $wScore = $workload.Value.complianceScore
            
            $wClass = "compliance-bad"
            if ($wScore -ge 90) { $wClass = "compliance-good" }
            elseif ($wScore -ge 70) { $wClass = "compliance-warning" }
            
            $scoreFormatted = [math]::Round($wScore, 1)
            $reportContent += "            <li>$($wName): <span class=`"$($wClass)`">$($scoreFormatted)%</span></li>`n"
        }

        $reportContent += @"
        </ul>
        
        <h3>Top Issues</h3>
        <ul>
"@

        # Add top 5 non-compliant issues
        $topIssues = $driftData.driftDetails | Where-Object { $_.status -eq "Non-Compliant" } | Select-Object -First 5
        
        if ($topIssues.Count -gt 0) {
            foreach ($issue in $topIssues) {
                $reportContent += "            <li><strong>$($issue.title)</strong> - $($issue.description)</li>`n"
            }
        } else {
            $reportContent += "            <li>No issues found</li>`n"
        }

        $reportContent += @"
        </ul>
"@

        if ($DetailedReport) {
            $reportContent += @"
        <button type="button" class="collapsible">Show All Configuration Issues</button>
        <div class="content">
            <div class="details-table">
                <table>
                    <tr>
                        <th>Workload</th>
                        <th>Requirement</th>
                        <th>Status</th>
                        <th>Description</th>
                    </tr>
"@

            foreach ($issue in $driftData.driftDetails) {
                $statusClass = "user-yes"
                if ($issue.status -eq "Non-Compliant") {
                    $statusClass = "user-no"
                }
                
                $reportContent += @"
                    <tr>
                        <td>$($issue.workload)</td>
                        <td>$($issue.title)</td>
                        <td class="$statusClass">$($issue.status)</td>
                        <td>$($issue.description)</td>
                    </tr>
"@
            }

            $reportContent += @"
                </table>
            </div>
        </div>
"@
        }

        $reportContent += @"
    </div>
"@
    }

    # Add AccessWatch results if available
    if ($recentAccessReport) {
        Write-Log "Adding AccessWatch results to report..." -Color Cyan
        
        # Read access report
        $accessData = Get-Content -Path $recentAccessReport.FullName -Raw | ConvertFrom-Json
        
        # Calculate MFA score
        $mfaScore = $accessData.mfaCompliance.mfaAdoptionRate
        $mfaClass = "compliance-bad"
        if ($mfaScore -ge 90) { $mfaClass = "compliance-good" }
        elseif ($mfaScore -ge 70) { $mfaClass = "compliance-warning" }
        
        $reportContent += @"
    <div class="section">
        <h2><span class="module-title">AccessWatch</span> Identity and Access Security</h2>
        
        <div class="summary-box">
            <h3>MFA Adoption</h3>
            <p class="$mfaClass">$($mfaScore.ToString("0.0"))%</p>
        </div>
        
        <div class="summary-box">
            <h3>Admin MFA</h3>
            <p>$($accessData.mfaCompliance.adminMfaAdoptionRate.ToString("0.0"))%</p>
        </div>
        
        <div class="summary-box">
            <h3>At-Risk Users</h3>
            <p>$($accessData.mfaCompliance.atRiskUsers.Count)</p>
        </div>
        
        <h3>Conditional Access Policies</h3>
        <p>MFA Policy Coverage: $($accessData.conditionalAccessAnalysis.mfaPolicyCoverage)</p>
"@

        if ($DetailedReport) {
            # Add detailed user MFA table
            $reportContent += @"
        
        <button type="button" class="collapsible">Show User MFA Status</button>
        <div class="content">
            <div class="details-table">
                <table>
                    <tr>
                        <th>User</th>
                        <th>MFA Enabled</th>
                        <th>Admin User</th>
                        <th>At Risk</th>
                    </tr>
"@

            foreach ($user in $accessData.userAnalysis) {
                $mfaClass = "user-no"
                if ($user.mfaEnabled) {
                    $mfaClass = "user-yes"
                }
                
                $adminClass = ""
                if ($user.isAdmin) {
                    $adminClass = "user-admin"
                }
                
                $rowClass = ""
                if ($accessData.mfaCompliance.atRiskUsers -contains $user.userPrincipalName) {
                    $rowClass = "user-warning"
                }
                
                $reportContent += @"
                    <tr class="$rowClass">
                        <td class="$adminClass">$($user.userPrincipalName)</td>
                        <td class="$mfaClass">$($user.mfaEnabled)</td>
                        <td>$($user.isAdmin)</td>
                        <td>$($accessData.mfaCompliance.atRiskUsers -contains $user.userPrincipalName)</td>
                    </tr>
"@
            }

            $reportContent += @"
                </table>
            </div>
        </div>
"@
        }
        
        $reportContent += @"
    </div>
"@
    }

    # Add LicenseLogic results if available
    if ($recentLicenseReport) {
        Write-Log "Adding LicenseLogic results to report..." -Color Cyan
        
        # Read license report
        $licenseData = Get-Content -Path $recentLicenseReport.FullName -Raw | ConvertFrom-Json
        
        $reportContent += @"
    <div class="section">
        <h2><span class="module-title">LicenseLogic</span> License Usage Optimization</h2>
        
        <div class="summary-box">
            <h3>Total Users</h3>
            <p>$($licenseData.metadata.totalUsers)</p>
        </div>
        
        <div class="summary-box">
            <h3>License SKUs</h3>
            <p>$($licenseData.metadata.totalSkus)</p>
        </div>
        
        <div class="summary-box">
            <h3>Optimization</h3>
            <p>Users without License: $($licenseData.metadata.usersWithNoLicense)</p>
            <p>Disabled with License: $($licenseData.metadata.disabledWithLicense)</p>
        </div>
"@

        if ($DetailedReport) {
            # Add detailed license table
            $reportContent += @"
        
        <button type="button" class="collapsible">Show User License Details</button>
        <div class="content">
            <div class="details-table">
                <table>
                    <tr>
                        <th>User</th>
                        <th>Account Enabled</th>
                        <th>Has License</th>
                        <th>Assigned Licenses</th>
                        <th>Optimization Needed</th>
                    </tr>
"@

            # Check if userLicenses is a property or an array
            $userLicenses = @()
            if ($licenseData.PSObject.Properties.Name -contains "userLicenses") {
                if ($licenseData.userLicenses -is [array]) {
                    $userLicenses = $licenseData.userLicenses
                }
            }
            
            if ($userLicenses.Count -eq 0) {
                # Try to extract user licenses from other properties
                if ($licenseData.PSObject.Properties.Name -contains "users") {
                    $userLicenses = $licenseData.users | ForEach-Object {
                        [PSCustomObject]@{
                            UserPrincipalName = $_.userPrincipalName
                            DisplayName = $_.displayName
                            IsEnabled = $_.accountEnabled
                            IsLicensed = ($_.assignedLicenses.Count -gt 0)
                            Licenses = ($_.assignedLicenses | ForEach-Object { $_.skuPartNumber }) -join ", "
                            OptimizationNeeded = (-not $_.accountEnabled -and $_.assignedLicenses.Count -gt 0)
                            OptimizationReason = if (-not $_.accountEnabled -and $_.assignedLicenses.Count -gt 0) { "Disabled account with license" } else { "" }
                        }
                    }
                }
            }

            foreach ($user in $userLicenses) {
                $enabledClass = "user-no"
                if ($user.IsEnabled) {
                    $enabledClass = "user-yes"
                }
                
                $licensedClass = "user-no"
                if ($user.IsLicensed) {
                    $licensedClass = "user-yes"
                }
                
                $rowClass = ""
                if ($user.OptimizationNeeded) {
                    $rowClass = "user-warning"
                }
                
                $reportContent += @"
                    <tr class="$rowClass">
                        <td>$($user.UserPrincipalName)</td>
                        <td class="$enabledClass">$($user.IsEnabled)</td>
                        <td class="$licensedClass">$($user.IsLicensed)</td>
                        <td>$($user.Licenses)</td>
                        <td>$($user.OptimizationReason)</td>
                    </tr>
"@
            }

            $reportContent += @"
                </table>
            </div>
        </div>
"@
            
            # Add license SKUs table
            $reportContent += @"
            
        <button type="button" class="collapsible">Show License SKUs</button>
        <div class="content">
            <div class="details-table">
                <table>
                    <tr>
                        <th>License SKU</th>
                        <th>Used</th>
                        <th>Total</th>
                    </tr>
"@

            foreach ($license in $licenseData.licenses) {
                $reportContent += @"
                    <tr>
                        <td>$($license.skuPartNumber)</td>
                        <td>$($license.consumedUnits)</td>
                        <td>$($license.prepaidUnits.enabled)</td>
                    </tr>
"@
            }

            $reportContent += @"
                </table>
            </div>
        </div>
"@
        }

        $reportContent += @"
    </div>
"@
    }
    
    # Add SCuBA results if available
    if ($UseScuba) {
        Write-Log "Adding SCuBA results to report..." -Color Cyan
                        
        if ($scubaDriftReport) {
            # Read SCuBA drift report
            $scubaData = Get-Content -Path $scubaDriftReport.FullName -Raw | ConvertFrom-Json
            
            # Calculate compliance score
            $scubaScore = $scubaData.summary.overallComplianceScore
            $scubaClass = "compliance-bad"
            if ($scubaScore -ge 90) { $scubaClass = "compliance-good" }
            elseif ($scubaScore -ge 70) { $scubaClass = "compliance-warning" }
            
            $reportContent += @"
    <div class="section">
        <h2><span class="module-title">SCuBA</span> CISA Secure Cloud Business Applications</h2>
        
        <div class="summary-box">
            <h3>Overall Compliance</h3>
            <p class="$scubaClass">$($scubaScore.ToString("0.0"))%</p>
        </div>
        
        <div class="summary-box">
            <h3>Requirements</h3>
            <p>Total: $($scubaData.summary.totalRequirements)</p>
            <p>Compliant: $($scubaData.summary.compliantRequirements)</p>
            <p>Non-Compliant: $($scubaData.summary.nonCompliantRequirements)</p>
        </div>
        
        <h3>Workload Compliance</h3>
        <ul>
"@

            # Add workload compliance
            foreach ($workload in $scubaData.workloads.PSObject.Properties) {
                $wName = $workload.Name
                $wScore = $workload.Value.complianceScore
                
                $wClass = "compliance-bad"
                if ($wScore -ge 90) { $wClass = "compliance-good" }
                elseif ($wScore -ge 70) { $wClass = "compliance-warning" }
                
                $scoreFormatted = [math]::Round($wScore, 1)
                $reportContent += "            <li>$($wName): <span class=`"$($wClass)`">$($scoreFormatted)%</span></li>`n"
            }

            $reportContent += @"
        </ul>
"@

            if ($DetailedReport) {
                $reportContent += @"
        <button type="button" class="collapsible">Show SCuBA Findings</button>
        <div class="content">
            <div class="details-table">
                <table>
                    <tr>
                        <th>Workload</th>
                        <th>Requirement</th>
                        <th>Status</th>
                        <th>Description</th>
                    </tr>
"@

                foreach ($issue in $scubaData.driftDetails) {
                    $statusClass = "user-yes"
                    if ($issue.status -eq "Non-Compliant") {
                        $statusClass = "user-no"
                    }
                    
                    $reportContent += @"
                    <tr>
                        <td>$($issue.workload)</td>
                        <td>$($issue.title)</td>
                        <td class="$statusClass">$($issue.status)</td>
                        <td>$($issue.description)</td>
                    </tr>
"@
                }

                $reportContent += @"
                </table>
            </div>
        </div>
"@
            }
            
            $reportContent += @"
    </div>
"@
        } else {
            $reportContent += @"
    <div class="section">
        <h2><span class="module-title">SCuBA</span> CISA Secure Cloud Business Applications</h2>
        <p>SCuBA assessment was run, but the results could not be imported. Please check the SCuBA output directory.</p>
        <p>The most likely causes are:</p>
        <ul>
            <li>SCuBA assessment is still running in the background (it can take 15-30 minutes)</li>
            <li>SCuBA encountered errors during the assessment</li>
            <li>SCuBA results were generated but stored in a different location</li>
        </ul>
        <p>To manually locate SCuBA results, look in the following locations:</p>
        <ul>
            <li>$scriptDir\M365BaselineConformance</li>
            <li>$scriptDir\Scuba</li>
            <li>$env:USERPROFILE\Documents\ScubaGear</li>
            <li>C:\ScubaGear</li>
        </ul>
    </div>
"@
        }
    }

    # Add collapsible sections JavaScript
    $reportContent += @"
    <script>
        var coll = document.getElementsByClassName("collapsible");
        var i;
        
        for (i = 0; i < coll.length; i++) {
            coll[i].addEventListener("click", function() {
                this.classList.toggle("active");
                var content = this.nextElementSibling;
                if (content.style.maxHeight) {
                    content.style.maxHeight = null;
                } else {
                    content.style.maxHeight = content.scrollHeight + "px";
                }
            });
        }
    </script>

    <footer>
        <p>Generated by SecurePulse - © $(Get-Date -Format "yyyy")</p>
        <p>Log file: $logFile</p>
    </footer>
</body>
</html>
"@
    
    # Save the report
    Set-Content -Path $reportFile -Value $reportContent
    
    Write-Log "Assessment complete!" -Color Green
    Write-Log "HTML Report is available at: $reportFile" -Color Green
    
    # Try to open the report in the default browser
    try {
        Start-Process $reportFile
    }
    catch {
        Write-Log "Report generated but could not be opened automatically. Please open it manually." -Color Yellow
    }
    
    Pop-Location
    
    Write-Log "============ ASSESSMENT COMPLETED ============" -Color Green
}
catch {
    Write-Log "ERROR during assessment: $_" -Color Red
    Write-Log "Error details:" -Color Red
    Write-Log $_.Exception -Color Red
    Write-Log $_.ScriptStackTrace -Color Red
}
finally {
    # Clear environment variables
    Remove-Item Env:\MS_CLIENT_ID -ErrorAction SilentlyContinue
    Remove-Item Env:\MS_CLIENT_SECRET -ErrorAction SilentlyContinue
    Remove-Item Env:\MS_TENANT_ID -ErrorAction SilentlyContinue
    
    # Stop transcript
    Stop-Transcript
}